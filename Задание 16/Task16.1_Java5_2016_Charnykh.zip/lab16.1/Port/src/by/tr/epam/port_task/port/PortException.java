package by.tr.epam.port_task.port;

public class PortException extends Exception {

	private static final long serialVersionUID = 1L;

	public PortException(String message){
		super(message);
	}

}
