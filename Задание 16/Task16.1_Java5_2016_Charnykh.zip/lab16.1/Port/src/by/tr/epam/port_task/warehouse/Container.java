package by.tr.epam.port_task.warehouse;

public class Container {
	private int id;
	
	public Container(int id){
		this.id = id;
	}
	
	public int getId(){
		return id;
	}
}
